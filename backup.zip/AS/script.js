function verificarRespuestas(){
	let points = 0;
	var optionValue = document.getElementById('selectbox').value;
	var optionValue2 = document.getElementById('selectbox2').value;
	var optionValue3 = document.getElementById('selectbox3').value;
	var optionValue4 = document.getElementById('selectbox4').value;
	var optionValue5 = document.getElementById('selectbox5').value;
	var optionValue6 = document.getElementById('selectbox6').value;
	var optionValue7 = document.getElementById('selectbox7').value;
	var optionValue8 = document.getElementById('selectbox8').value;
	var optionValue9 = document.getElementById('selectbox9').value;
	var optionValue10 = document.getElementById('selectbox10').value;
	var optionValue11 = document.getElementById('selectbox11').value;
	var optionValue12 = document.getElementById('selectbox12').value;
	var optionValue13 = document.getElementById('selectbox13').value;
	var optionValue14 = document.getElementById('selectbox14').value;
	var optionValue15 = document.getElementById('selectbox15').value;
	var optionValue16 = document.getElementById('selectbox16').value;
	var optionValue17 = document.getElementById('selectbox17').value;
	var optionValue18 = document.getElementById('selectbox18').value;
	var optionValue19 = document.getElementById('selectbox19').value;
	var optionValue20 = document.getElementById('selectbox20').value;
	var optionValue21 = document.getElementById('selectbox21').value;
	var optionValue22 = document.getElementById('selectbox22').value;
	var optionValue23 = document.getElementById('selectbox23').value;
	var optionValue24 = document.getElementById('selectbox24').value;
	var optionValue25 = document.getElementById('selectbox25').value;
	var optionValue26 = document.getElementById('selectbox26').value;
	var optionValue27 = document.getElementById('selectbox27').value;
	var optionValue28 = document.getElementById('selectbox28').value;
	var optionValue29 = document.getElementById('selectbox29').value;
	var optionValue30 = document.getElementById('selectbox30').value;
	var optionValue31 = document.getElementById('selectbox31').value;
	var optionValue32 = document.getElementById('selectbox32').value;
	var optionValue33 = document.getElementById('selectbox33').value;
	var optionValue34 = document.getElementById('selectbox34').value;


	if (optionValue == 1) {
	points++;	
	document.getElementById('selectbox').classList.add('green-f');
	}
	else if (optionValue == 0) {
		document.getElementById('selectbox').classList.add('rojo-f');
	}

	if (optionValue2 == 1) {
	points++;	
	document.getElementById('selectbox2').classList.add('green-f');
	}
	else if (optionValue2 == 0) {
		document.getElementById('selectbox2').classList.add('rojo-f');
	}

	if (optionValue3 == 1) {
	points++;	
	document.getElementById('selectbox3').classList.add('green-f');
	}
	else if (optionValue3 == 0) {
		document.getElementById('selectbox3').classList.add('rojo-f');
	}

	if (optionValue4 == 1) {
	points++;	
	document.getElementById('selectbox4').classList.add('green-f');
	}
	else if (optionValue4 == 0) {
		document.getElementById('selectbox4').classList.add('rojo-f');
	}

	if (optionValue5 == 1) {
	points++;	
	document.getElementById('selectbox5').classList.add('green-f');
	}
	else if (optionValue5 == 0) {
		document.getElementById('selectbox5').classList.add('rojo-f');
	}

	if (optionValue6 == 1) {
	points++;	
	document.getElementById('selectbox6').classList.add('green-f');
	}
	else if (optionValue6 == 0) {
		document.getElementById('selectbox6').classList.add('rojo-f');
	}

	if (optionValue7 == 1) {
	points++;	
	document.getElementById('selectbox7').classList.add('green-f');
	}
	else if (optionValue7 == 0) {
		document.getElementById('selectbox7').classList.add('rojo-f');
	}

	if (optionValue8 == 1) {
	points++;	
	document.getElementById('selectbox8').classList.add('green-f');
	}
	else if (optionValue8 == 0) {
		document.getElementById('selectbox8').classList.add('rojo-f');
	}

	if (optionValue9 == 1) {
	points++;	
	document.getElementById('selectbox9').classList.add('green-f');
	}
	else if (optionValue9 == 0) {
		document.getElementById('selectbox9').classList.add('rojo-f');
	}

	if (optionValue10 == 1) {
	points++;	
	document.getElementById('selectbox10').classList.add('green-f');
	}
	else if (optionValue10 == 0) {
		document.getElementById('selectbox10').classList.add('rojo-f');
	}

	if (optionValue11 == 1) {
	points++;	
	document.getElementById('selectbox11').classList.add('green-f');
	}
	else if (optionValue11 == 0) {
		document.getElementById('selectbox11').classList.add('rojo-f');
	}

	if (optionValue12 == 1) {
	points++;	
	document.getElementById('selectbox12').classList.add('green-f');
	}
	else if (optionValue12 == 0) {
		document.getElementById('selectbox12').classList.add('rojo-f');
	}

	if (optionValue13 == 1) {
	points++;	
	document.getElementById('selectbox13').classList.add('green-f');
	}
	else if (optionValue13 == 0) {
		document.getElementById('selectbox13').classList.add('rojo-f');
	}

	if (optionValue14 == 1) {
	points++;	
	document.getElementById('selectbox14').classList.add('green-f');
	}
	else if (optionValue14 == 0) {
		document.getElementById('selectbox14').classList.add('rojo-f');
	}

	if (optionValue15 == 1) {
	points++;	
	document.getElementById('selectbox15').classList.add('green-f');
	}
	else if (optionValue15 == 0) {
		document.getElementById('selectbox15').classList.add('rojo-f');
	}

	if (optionValue16 == 1) {
	points++;	
	document.getElementById('selectbox16').classList.add('green-f');
	}
	else if (optionValue16 == 0) {
		document.getElementById('selectbox16').classList.add('rojo-f');
	}

	if (optionValue17 == 1) {
	points++;	
	document.getElementById('selectbox17').classList.add('green-f');
	}
	else if (optionValue17 == 0) {
		document.getElementById('selectbox17').classList.add('rojo-f');
	}

	if (optionValue18 == 1) {
	points++;	
	document.getElementById('selectbox18').classList.add('green-f');
	}
	else if (optionValue18 == 0) {
		document.getElementById('selectbox18').classList.add('rojo-f');
	}

	if (optionValue19 == 1) {
	points++;	
	document.getElementById('selectbox19').classList.add('green-f');
	}
	else if (optionValue19 == 0) {
		document.getElementById('selectbox19').classList.add('rojo-f');
	}

	if (optionValue20 == 1) {
	points++;	
	document.getElementById('selectbox20').classList.add('green-f');
	}
	else if (optionValue20 == 0) {
		document.getElementById('selectbox20').classList.add('rojo-f');
	}

	if (optionValue21 == 1) {
	points++;	
	document.getElementById('selectbox21').classList.add('green-f');
	}
	else if (optionValue21 == 0) {
		document.getElementById('selectbox21').classList.add('rojo-f');
	}

	if (optionValue22 == 1) {
	points++;	
	document.getElementById('selectbox22').classList.add('green-f');
	}
	else if (optionValue22 == 0) {
		document.getElementById('selectbox22').classList.add('rojo-f');
	}

	if (optionValue23 == 1) {
	points++;	
	document.getElementById('selectbox23').classList.add('green-f');
	}
	else if (optionValue23 == 0) {
		document.getElementById('selectbox23').classList.add('rojo-f');
	}

	if (optionValue24 == 1) {
	points++;	
	document.getElementById('selectbox24').classList.add('green-f');
	}
	else if (optionValue24 == 0) {
		document.getElementById('selectbox24').classList.add('rojo-f');
	}

	if (optionValue25 == 1) {
	points++;	
	document.getElementById('selectbox25').classList.add('green-f');
	}
	else if (optionValue25 == 0) {
		document.getElementById('selectbox25').classList.add('rojo-f');
	}

	if (optionValue26 == 1) {
	points++;	
	document.getElementById('selectbox26').classList.add('green-f');
	}
	else if (optionValue26 == 0) {
		document.getElementById('selectbox26').classList.add('rojo-f');
	}

	if (optionValue27 == 1) {
	points++;	
	document.getElementById('selectbox27').classList.add('green-f');
	}
	else if (optionValue27 == 0) {
		document.getElementById('selectbox27').classList.add('rojo-f');
	}

	if (optionValue28 == 1) {
	points++;	
	document.getElementById('selectbox28').classList.add('green-f');
	}
	else if (optionValue28 == 0) {
		document.getElementById('selectbox28').classList.add('rojo-f');
	}

	if (optionValue29 == 1) {
	points++;	
	document.getElementById('selectbox29').classList.add('green-f');
	}
	else if (optionValue29 == 0) {
		document.getElementById('selectbox29').classList.add('rojo-f');
	}

	if (optionValue30 == 1) {
	points++;	
	document.getElementById('selectbox30').classList.add('green-f');
	}
	else if (optionValue30 == 0) {
		document.getElementById('selectbox30').classList.add('rojo-f');
	}

	if (optionValue31 == 1) {
	points++;	
	document.getElementById('selectbox31').classList.add('green-f');
	}
	else if (optionValue31 == 0) {
		document.getElementById('selectbox31').classList.add('rojo-f');
	}

	if (optionValue32 == 1) {
	points++;	
	document.getElementById('selectbox32').classList.add('green-f');
	}
	else if (optionValue32 == 0) {
		document.getElementById('selectbox32').classList.add('rojo-f');
	}

	if (optionValue33 == 1) {
	points++;	
	document.getElementById('selectbox33').classList.add('green-f');
	}
	else if (optionValue33 == 0) {
		document.getElementById('selectbox33').classList.add('rojo-f');
	}

	if (optionValue34 == 1) {
	points++;	
	document.getElementById('selectbox34').classList.add('green-f');
	}
	else if (optionValue34 == 0) {
		document.getElementById('selectbox34').classList.add('rojo-f');
	}

	if (points < 16) 
	{
		swal("Fallaste, pero no te rindas!!!","Tenes "+points+" de 34 puntos","error");
	}
	else
	 {
        swal("Aprobaste, Felicidades!!!", "Tenes "+points+" de 34 puntos","success",
        {closeOnClickOutside: false}).then((value)=>{
            window. location = "https://overtime21.000webhostapp.com/pagina5.html";
        });	}
}