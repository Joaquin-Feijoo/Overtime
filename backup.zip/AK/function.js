function resultado(){
	let c=0;
	var s1=document.getElementById('select1').value;
	var s2=document.getElementById('select2').value;
	var s3=document.getElementById('select3').value;
	var s4=document.getElementById('select4').value;
	var s5=document.getElementById('select5').value;
	var s6=document.getElementById('select6').value;
	var s7=document.getElementById('select7').value;
	var s8=document.getElementById('select8').value;
	var s9=document.getElementById('select9').value;
	var s10=document.getElementById('select10').value;
	var s11=document.getElementById('select11').value;
	var s12=document.getElementById('select12').value;
	var s13=document.getElementById('select13').value;
	var s14=document.getElementById('select14').value;
	var s15=document.getElementById('select15').value;
	var s16=document.getElementById('select16').value;
	var s17=document.getElementById('select17').value;
	var s18=document.getElementById('select18').value;
	var s19=document.getElementById('select19').value;
	var s20=document.getElementById('select20').value;
	var s21=document.getElementById('select21').value;
	var s22=document.getElementById('select22').value;
	var s23=document.getElementById('select23').value;
	var s24=document.getElementById('select24').value;
	var s25=document.getElementById('select25').value;
	var s26=document.getElementById('select26').value;
	var s27=document.getElementById('select27').value;
	var s28=document.getElementById('select28').value;
	var s29=document.getElementById('select29').value;
	var s30=document.getElementById('select30').value;
	var s31=document.getElementById('select31').value;
	var s32=document.getElementById('select32').value;
	var s33=document.getElementById('select33').value;
	var s34=document.getElementById('select34').value;
	var s35=document.getElementById('select35').value;
	var s36=document.getElementById('select36').value;

	if(s1==1){
		c++;
		document.getElementById('select1').classList.add('bkl-green');
	}
	else{
		document.getElementById('select1').classList.add('bkl-red');
	}
	if(s2==1){
		c++;
		document.getElementById('select2').classList.add('bkl-green');
	}
	else{
		document.getElementById('select2').classList.add('bkl-red');
	}
	if(s3==1){
		c++;
		document.getElementById('select3').classList.add('bkl-green');
	}
	else{
		document.getElementById('select3').classList.add('bkl-red');
	}

	if(s4==1){
		c++;
		document.getElementById('select4').classList.add('bkl-green');
	}
	else{
		document.getElementById('select4').classList.add('bkl-red');
	}
	if(s5==1){
		c++;
		document.getElementById('select5').classList.add('bkl-green');
	}
	else{
		document.getElementById('select5').classList.add('bkl-red');
	}
	if(s6==1){
		c++;
		document.getElementById('select6').classList.add('bkl-green');
	}
	else{
		document.getElementById('select6').classList.add('bkl-red');
	}

	if(s7==1){
		c++;
		document.getElementById('select7').classList.add('bkl-green');
	}
	else{
		document.getElementById('select7').classList.add('bkl-red');
	}
	if(s8==1){
		c++;
		document.getElementById('select8').classList.add('bkl-green');
	}
	else{
		document.getElementById('select8').classList.add('bkl-red');
	}
	if(s9==1){
		c++;
		document.getElementById('select9').classList.add('bkl-green');
	}
	else{
		document.getElementById('select9').classList.add('bkl-red');
	}
	if(s10==1){
		c++;
		document.getElementById('select10').classList.add('bkl-green');
	}
	else{
		document.getElementById('select10').classList.add('bkl-red');
	}
	if(s11==1){
		c++;
		document.getElementById('select11').classList.add('bkl-green');
	}
	else{
		document.getElementById('select11').classList.add('bkl-red');
	}
	if(s12==1){
		c++;
		document.getElementById('select12').classList.add('bkl-green');
	}
	else{
		document.getElementById('select12').classList.add('bkl-red');
	}
	if(s13==1){
		c++;
		document.getElementById('select13').classList.add('bkl-green');
	}
	else{
		document.getElementById('select13').classList.add('bkl-red');
	}
	if(s14==1){
		c++;
		document.getElementById('select14').classList.add('bkl-green');
	}
	else{
		document.getElementById('select14').classList.add('bkl-red');
	}
	if(s15==1){
		c++;
		document.getElementById('select15').classList.add('bkl-green');
	}
	else{
		document.getElementById('select15').classList.add('bkl-red');
	}
	if(s16==1){
		c++;
		document.getElementById('select16').classList.add('bkl-green');
	}
	else{
		document.getElementById('select16').classList.add('bkl-red');
	}
	if(s17==1){
		c++;
		document.getElementById('select17').classList.add('bkl-green');
	}
	else{
		document.getElementById('select17').classList.add('bkl-red');
	}
	if(s18==1){
		c++;
		document.getElementById('select18').classList.add('bkl-green');
	}
	else{
		document.getElementById('select18').classList.add('bkl-red');
	}
	if(s19==1){
		c++;
		document.getElementById('select19').classList.add('bkl-green');
	}
	else{
		document.getElementById('select19').classList.add('bkl-red');
	}
	if(s20==1){
		c++;
		document.getElementById('select20').classList.add('bkl-green');
	}
	else{
		document.getElementById('select20').classList.add('bkl-red');
	}
	if(s21==1){
		c++;
		document.getElementById('select21').classList.add('bkl-green');
	}
	else{
		document.getElementById('select21').classList.add('bkl-red');
	}
	if(s22==1){
		c++;
		document.getElementById('select22').classList.add('bkl-green');
	}
	else{
		document.getElementById('select22').classList.add('bkl-red');
	}
	if(s23==1){
		c++;
		document.getElementById('select23').classList.add('bkl-green');
	}
	else{
		document.getElementById('select23').classList.add('bkl-red');
	}
	if(s24==1){
		c++;
		document.getElementById('select24').classList.add('bkl-green');
	}
	else{
		document.getElementById('select24').classList.add('bkl-red');
	}
	if(s25==1){
		c++;
		document.getElementById('select25').classList.add('bkl-green');
	}
	else{
		document.getElementById('select25').classList.add('bkl-red');
	}
	if(s26==1){
		c++;
		document.getElementById('select26').classList.add('bkl-green');
	}
	else{
		document.getElementById('select26').classList.add('bkl-red');
	}
	if(s27==1){
		c++;
		document.getElementById('select27').classList.add('bkl-green');
	}
	else{
		document.getElementById('select27').classList.add('bkl-red');
	}
	if(s28==1){
		c++;
		document.getElementById('select28').classList.add('bkl-green');
	}
	else{
		document.getElementById('select28').classList.add('bkl-red');
	}
	if(s29==1){
		c++;
		document.getElementById('select29').classList.add('bkl-green');
	}
	else{
		document.getElementById('select29').classList.add('bkl-red');
	}
	if(s30==1){
		c++;
		document.getElementById('select30').classList.add('bkl-green');
	}
	else{
		document.getElementById('select30').classList.add('bkl-red');
	}
	if(s31==1){
		c++;
		document.getElementById('select31').classList.add('bkl-green');
	}
	else{
		document.getElementById('select31').classList.add('bkl-red');
	}
	if(s32==1){
		c++;
		document.getElementById('select32').classList.add('bkl-green');
	}
	else{
		document.getElementById('select32').classList.add('bkl-red');
	}
	if(s33==1){
		c++;
		document.getElementById('select33').classList.add('bkl-green');
	}
	else{
		document.getElementById('select33').classList.add('bkl-red');
	}
	if(s34==1){
		c++;
		document.getElementById('select34').classList.add('bkl-green');
	}
	else{
		document.getElementById('select34').classList.add('bkl-red');
	}
	if(s35==1){
		c++;
		document.getElementById('select35').classList.add('bkl-green');
	}
	else{
		document.getElementById('select35').classList.add('bkl-red');
	}
	if(s36==1){
		c++;
		document.getElementById('select36').classList.add('bkl-green');
	}
	else{
		document.getElementById('select36').classList.add('bkl-red');
	}


	if(c<18){
		swal("Ups.. Segui intentando","Tenes "+c+" de 36 puntos","error");
	}
	else{
        swal("Felicidades!! Pasaste", "Tenes "+c+" de 36 puntos","success",
        {closeOnClickOutside: false}).then((value)=>{
            window. location = "https://overtime21.000webhostapp.com/pagina4.html";
        });	}
}