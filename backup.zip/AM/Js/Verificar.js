function verificarRespuestas(){
    let total = 72;
    let points = 0;
    var optionValue = document.getElementById('selectbox1').value;
    var optionValue2 = document.getElementById('selectbox2').value;
    var optionValue3 = document.getElementById('selectbox3').value;
    var optionValue4 = document.getElementById('selectbox4').value;
    var optionValue5 = document.getElementById('selectbox5').value;
    var optionValue6 = document.getElementById('selectbox6').value;
    var optionValue7 = document.getElementById('selectbox7').value;
    var optionValue8 = document.getElementById('selectbox8').value;
    var optionValue9 = document.getElementById('selectbox9').value;
    var optionValue10 = document.getElementById('selectbox10').value;
    var optionValue11 = document.getElementById('selectbox11').value;
    var optionValue12 = document.getElementById('selectbox12').value;
    var optionValue13 = document.getElementById('selectbox13').value;
    var optionValue14 = document.getElementById('selectbox14').value;
    var optionValue15 = document.getElementById('selectbox15').value;
    var optionValue16 = document.getElementById('selectbox16').value;
    var optionValue17 = document.getElementById('selectbox17').value;
    var optionValue18 = document.getElementById('selectbox18').value;
    var optionValue19 = document.getElementById('selectbox19').value;
    var optionValue20 = document.getElementById('selectbox20').value;
    var optionValue21 = document.getElementById('selectbox21').value;
    var optionValue22 = document.getElementById('selectbox22').value;
    var optionValue23 = document.getElementById('selectbox23').value;
    var optionValue24 = document.getElementById('selectbox24').value;
    var optionValue25 = document.getElementById('selectbox25').value;
    var optionValue26 = document.getElementById('selectbox26').value;
    var optionValue27 = document.getElementById('selectbox27').value;
    var optionValue29 = document.getElementById('selectbox29').value;
    var optionValue30 = document.getElementById('selectbox30').value;
    var optionValue31 = document.getElementById('selectbox31').value;
    var optionValue32 = document.getElementById('selectbox32').value;
    var optionValue33 = document.getElementById('selectbox33').value;
    var optionValue34 = document.getElementById('selectbox34').value;
    var optionValuE35 = document.getElementById('selectbox35').value;
    var optionValue36 = document.getElementById('selectbox36').value;
    var optionValue37 = document.getElementById('selectbox37').value;
    var optionValue38 = document.getElementById('selectbox38').value;
    var optionValue39 = document.getElementById('selectbox39').value;
    var optionValue40 = document.getElementById('selectbox40').value;
    var optionValue41 = document.getElementById('selectbox41').value;
    var optionValue42 = document.getElementById('selectbox42').value;
    var optionValue43 = document.getElementById('selectbox43').value;
    var optionValue44 = document.getElementById('selectbox44').value;
    var optionValue45 = document.getElementById('selectbox45').value;
    var optionValue46 = document.getElementById('selectbox46').value;
    var optionValue47 = document.getElementById('selectbox47').value;
    var optionValue48 = document.getElementById('selectbox48').value;
    var optionValue49 = document.getElementById('selectbox49').value;
    var optionValue50 = document.getElementById('selectbox50').value;
    var optionValue51 = document.getElementById('selectbox51').value;
    var optionValue52 = document.getElementById('selectbox52').value;
    var optionValue53 = document.getElementById('selectbox53').value;
    var optionValue54 = document.getElementById('selectbox54').value;
    var optionValue55 = document.getElementById('selectbox55').value;
    var optionValue56 = document.getElementById('selectbox56').value;
    var optionValue57 = document.getElementById('selectbox57').value;
    var optionValue58 = document.getElementById('selectbox58').value;
    var optionValue59 = document.getElementById('selectbox59').value;
    var optionValue60 = document.getElementById('selectbox60').value;
    var optionValue61 = document.getElementById('selectbox61').value;
    var optionValuE62 = document.getElementById('selectbox62').value;
    var optionValue63 = document.getElementById('selectbox63').value;
    var optionValue64 = document.getElementById('selectbox64').value;
    var optionValue65 = document.getElementById('selectbox65').value;
    var optionValue66 = document.getElementById('selectbox66').value;
    var optionValue67 = document.getElementById('selectbox67').value;
    var optionValue68 = document.getElementById('selectbox68').value;
    var optionValue69 = document.getElementById('selectbox69').value;
    var optionValue70 = document.getElementById('selectbox70').value;
    var optionValue71 = document.getElementById('selectbox71').value;
    var optionValue72 = document.getElementById('selectbox72').value;




    if (optionValue == 1) {
    points++;   
    }

    if (optionValue2 == 1) {
    points++;   
    }


    if (optionValue3 == 1) {
   
    points++;   
    }
    

    if (optionValue4 == 1) {
    points++;   
    }

    if (optionValue5 == 1) {
    points++;   
    
    }

    if (optionValue6 == 1) {
    points++;   
    }
    

    if (optionValue7 == 1) {
    points++;   
    }

    if (optionValue8 == 1) {
    points++;   
    }
    if (optionValue9 == 1) {
    points++;   
    
    }

    if (optionValue10 == 1) {
    points++;   
    
    }

    if (optionValue11 == 1) {
    points++;   
   
    }

    if (optionValue12 == 1) {
    points++;   
    
    }

    if (optionValue13 == 1) {
    points++;   
    
    }

    if (optionValue14 == 1) {
    points++;   
    
    }

    if (optionValue15 == 1) {
    points++;   
    
    }

    if (optionValue16 == 1) {
    points++;   
    
    }

    if (optionValue17 == 1) {
    points++;   
    
    }

    if (optionValue18 == 1) {
    points++;   
    
    }

    if (optionValue19 == 1) {
    points++;   
    
    }

    if (optionValue20 == 1) {
  
    points++;   
   
    }
  
    if (optionValue21 == 1) {
    points++;   
  
    }
   

    if (optionValue22 == 1) {
    points++;   
    
    }
 

    if (optionValue23 == 1) {
    points++;   
    
    }

    if (optionValue24 == 1) {
    points++;   
  
    }

    if (optionValue25 == 1) {
    points++;   
    
    }

    if (optionValue26 == 1) {
    points++;   
    
    }

    if (optionValue27 == 1) {
    points++;   
    
    }

    if (optionValue29 == 1) {
    points++;   
    
    }

    if (optionValue30 == 1) {
    points++;   
    
    }

    if (optionValue31 == 1) {
    points++;   
        
    }

    if (optionValue32 == 1) {
    points++;   
    
    }

    if (optionValue33 == 1) {
    points++;   
    
    }

    if (optionValue34 == 1) {
    points++;   
    
    }

    if (optionValue36 == 1) {
    points++;   
    
    }
    if (optionValue37 == 1) {
    points++;   
    
    }
    if (optionValue34 == 1) {
    points++;   
    
    }
    if (optionValue38 == 1) {
    points++;   
    
    }
    if (optionValue39 == 1) {
    points++;   
    
    }
    if (optionValue40 == 1) {
    points++;   
    
    }
    if (optionValue41 == 1) {
    points++;   
    
    }
    if (optionValue42 == 1) {
    points++;   
    
    }
    if (optionValue43 == 1) {
    points++;   
    
    }
    if (optionValue34 == 1) {
    points++;   
    
    }
    if (optionValue44 == 1) {
    points++;   
    
    }
    if (optionValue45 == 1) {
    points++;   
    
    }
    if (optionValue46 == 1) {
    points++;   
    
    }
    if (optionValue47 == 1) {
    points++;   
    
    }
    if (optionValue48 == 1) {
    points++;   
    
    }
    if (optionValue49 == 1) {
    points++;   
    
    }
    if (optionValue50 == 1) {
    points++;   
    
    }
    if (optionValue51 == 1) {
    points++;   
    
    }
    if (optionValue52 == 1) {
    points++;   
    
    }
    if (optionValue53 == 1) {
    points++;   
    
    }
    if (optionValue34 == 1) {
    points++;   
    
    }
    if (optionValue54 == 1) {
    points++;   
    
    }
    if (optionValue55 == 1) {
    points++;   
    
    }
    if (optionValue56 == 1) {
    points++;   
    
    }
    if (optionValue57 == 1) {
    points++;   
    
    }
    if (optionValue58 == 1) {
    points++;   
    
    }
    if (optionValue59 == 1) {
    points++;   
    
    }
    if (optionValue60 == 1) {
    points++;   
    
    }
    if (optionValue61 == 1) {
    points++;   
    
    }
    
    if (optionValue63 == 1) {
    points++;   
    
    }
    if (optionValue64 == 1) {
    points++;   
    
    }
    if (optionValue65 == 1) {
    points++;   
    
    }
    if (optionValue66 == 1) {
    points++;   
    
    }
    if (optionValue67 == 1) {
    points++;   
    
    }
    if (optionValue68 == 1) {
    points++;   
    
    }
    if (optionValue69 == 1) {
    points++;   
    
    }
    if (optionValue70 == 1) {
    points++;   
    
    }
    if (optionValue71 == 1) {
    points++;   
    
    }
    if (optionValue72 == 1) {
    points++;   
    
    }

if (points < 72) 
    {
        swal("Mala suerte, intentalo otra vez!!!","Tenes "+points+" de 72 puntos","error");
    }
    else
     {
        swal("Muy bien!!!", "Tenes "+points+" de 72 puntos","success");
    }
}